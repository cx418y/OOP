extern int size; 
