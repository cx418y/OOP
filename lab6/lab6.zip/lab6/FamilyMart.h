#ifndef FAMILYMART_H
#define FAMILYMART_H
//TODO 
// you need to modify this file
// you need to finish this class, but don't change the definition of the existing functions below.

class FamilyMart {
    public:
        FamilyMart();  // no any commodity
    
    	// using file name to construct FamilyMart
    	// the format of file is the same as purchase.txt
        FamilyMart(const string& cmmodity_file_name); 
    
    	// using file name add new commodities in every morning, the format of file is the same as purchase.txt
        void purchase_file(const string& cmmodity_file_name);
    
    	//the same as above, this is sell process
        void sell_file(const string& sellFile);
    
    	//return a total sales, a turnover snice the start of new FamilyMart.
        double show_turnover();
    
    	// ... your other function

    private:
    	// some attributes

};
#endif //FAMILYMART_H