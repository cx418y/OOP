#include <string.h>
#include <stdio.h>

#include <cstdlib>

using std::string;  

//比较两个日期,date1>date2返回正数
int compare_date(string date1,string date2){
	//分割字符串，得到年、月、天
	int pos1 = 0;
	int pos2 = 0;
	int year1 = 0;
	int month1 = 0;
	int day1 = 0;
	pos1 = date1.find("/", 0);
	pos2 = date1.find("/",pos1+1);
	year1 = std::stoi(date1.substr(0,4));
	month1 = std::stoi(date1.substr(5,pos2-pos1-1));
	day1 = std::stoi(date1.substr(pos2+1,date1.length()-pos2-1));

	int pos3 = 0;
	int pos4 = 0;
	int year2 = 0;
	int month2 = 0;
	int day2 = 0;
	pos3 = date2.find("/", 0);
	pos4 = date2.find("/",pos3+1);
	year2 = std::stoi(date2.substr(0,4));
	month2 = std::stoi(date2.substr(5,pos4-pos3-1));
	day2 = std::stoi(date2.substr(pos4+1,date2.length()-pos4-1));

	if(year1 == year2){
		if(month1 == month2){
			return day1 - day2;
		}else{
			return month1 - month2;
		}
	}else{
		return year1 - year2;
	}
	
	return 1;
}
    	
    	
 //日期加上某天树数
string date_add(string date, int days){
	//分割date
	int pos1 = 0;
	int pos2 = 0;
	int year = 0;
	int month = 0;
	int day = 0;
	pos1 = date.find("/", 0);
	pos2 = date.find("/",pos1+1);
	year = std::stoi(date.substr(0,4));
	month = std::stoi(date.substr(5,pos2-pos1-1));
	day = std::stoi(date.substr(pos2+1,date.length()-pos2-1));

    //二月:
	if(month == 2){
		if(day + days <= 28){
			day = day +days;
		}else{
			month++;
			day = day + days - 28;
		}
	}
	else if(month == 12){//12月
		if(day + days <= 30){
			day = day +days;
		}else{
			month = 1;
			day = day + days - 28;
			year++;
		}   
	}else if((month <= 6 && month % 2 ==0)||(month >= 9 && month % 2 == 1)){   //小月
	    if(day + days <= 30){
			day = day +days;
		}else{
			month++;
			day = day + days - 30;
		}
	}else{  //大月
		 if(day + days <= 31){
			day = day +days;
		}else{
			month++;
			day = day + days - 31;
		}
	}
	date = std::to_string(year)+"/" +std::to_string(month)+"/"+std::to_string(day);
	return date;
} 
